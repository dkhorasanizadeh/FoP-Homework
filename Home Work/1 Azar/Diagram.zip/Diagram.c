#include <stdio.h>
#include <math.h>
int main(void)
{
    int number, digits;
    scanf("%d", &number);
    digits = log10(number) + 1;
    if ((digits % 2) == 0)
    {
        int sum = 0;
        while (number > 0)
        {
            sum = sum + (number % 10);
            number = floor(number / 10);
        }
        printf("%d", sum);
    }
    else
    {
        int middle = (number / pow(10, ((digits - 1) / 2)));
        printf("%d", middle % 10);
    }
}